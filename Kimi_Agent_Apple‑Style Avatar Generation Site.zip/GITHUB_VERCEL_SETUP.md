# GitHub + Vercel Setup Guide for AvatarGen Studio

## 🚀 Quick Overview

This guide will walk you through:
1. Creating a GitHub repository
2. Pushing your code to GitHub
3. Deploying to Vercel with environment variables

---

## Part 1: GitHub Setup

### Step 1: Create a GitHub Account (if you don't have one)
1. Go to [github.com](https://github.com)
2. Click "Sign up" and follow the prompts
3. Verify your email

### Step 2: Create a New Repository
1. Click the **+** icon in the top right → **New repository**
2. Fill in the details:
   - **Repository name**: `avatargen-studio`
   - **Description**: `AI avatar video generation platform powered by Heygen`
   - **Visibility**: Public (or Private if you prefer)
   - **Initialize with README**: ❌ Uncheck this
3. Click **Create repository**

### Step 3: Push Your Code to GitHub

Open your terminal/command prompt and run these commands:

```bash
# Navigate to your project folder
cd /mnt/okcomputer/output/app

# Initialize Git (if not already done)
git init

# Add all files
git add .

# Commit the changes
git commit -m "Initial commit: AvatarGen Studio with Heygen API integration"

# Add the remote repository (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/avatargen-studio.git

# Push to GitHub
git push -u origin main
```

If you get an error about `main` vs `master`, try:
```bash
git branch -M main
git push -u origin main
```

### Step 4: Verify on GitHub
1. Go to `https://github.com/YOUR_USERNAME/avatargen-studio`
2. You should see all your files uploaded!

---

## Part 2: Vercel Setup

### Step 1: Create a Vercel Account
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up"
3. Choose **"Continue with GitHub"** (recommended)
4. Authorize Vercel to access your GitHub account

### Step 2: Import Your Repository
1. On Vercel dashboard, click **"Add New Project"**
2. Find and select your `avatargen-studio` repository
3. Click **"Import"**

### Step 3: Configure Project Settings

**Build & Output Settings:**
- **Framework Preset**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`

**Root Directory:**
- Leave as `./` (root)

### Step 4: Add Environment Variables

This is **CRITICAL** for the Heygen API to work!

Click **"Environment Variables"** and add:

| Name | Value |
|------|-------|
| `VITE_HEYGEN_API_KEY` | `sk_V2_hgu_kkV22wYOe8e_uFjmvvtSwTgLwPaoBkQhp3gdk2uiq3Xl` |

⚠️ **Important**: The API key is already in your code, but adding it to Vercel ensures it's secure and won't be exposed in your GitHub repo.

### Step 5: Deploy!
1. Click **"Deploy"**
2. Wait for the build to complete (usually 1-2 minutes)
3. Your site will be live at: `https://avatargen-studio.vercel.app`

---

## Part 3: Custom Domain (Optional)

### Add a Custom Domain
1. In Vercel dashboard, go to your project
2. Click **"Settings"** → **"Domains"**
3. Enter your domain (e.g., `avatargen.yourdomain.com`)
4. Follow the DNS configuration instructions

---

## Part 4: Updating Your Site

### Making Changes

Whenever you update your code:

```bash
# Navigate to project
cd /mnt/okcomputer/output/app

# Make your changes...

# Commit and push
git add .
git commit -m "Your update message"
git push origin main
```

Vercel will **automatically redeploy** your site when you push to GitHub!

---

## 🔐 Security Best Practices

### 1. Never Commit API Keys to GitHub

Your `.env` file is already in `.gitignore`, but double-check:

```bash
# Check what's being tracked
git status

# If .env shows up, remove it from tracking
git rm --cached .env
git commit -m "Remove .env from tracking"
```

### 2. Use Vercel Environment Variables

Always add sensitive keys in Vercel dashboard, not in your code.

### 3. Rotate API Keys Regularly

In your Heygen dashboard:
1. Go to Settings → API
2. Regenerate your API key periodically
3. Update it in Vercel environment variables

---

## 🐛 Troubleshooting

### Build Fails on Vercel

**Problem**: `Error: Cannot find module 'xyz'`

**Solution**: 
1. Check your `package.json` has all dependencies
2. Make sure `node_modules` is in `.gitignore`
3. Try redeploying with "Clear Cache and Redeploy"

### API Not Working

**Problem**: Videos not generating

**Solution**:
1. Check Vercel logs (Functions tab)
2. Verify `VITE_HEYGEN_API_KEY` is set correctly
3. Test the API key locally first

### CORS Errors

**Problem**: `Access-Control-Allow-Origin` errors

**Solution**: 
- Heygen API supports CORS, so this shouldn't happen
- If it does, you may need a backend proxy (see Advanced section)

---

## 📁 Project Structure

```
avatargen-studio/
├── .env                      # API keys (DO NOT COMMIT)
├── .env.example              # Example env file
├── .gitignore               # Git ignore rules
├── index.html               # HTML entry point
├── package.json             # Dependencies
├── README.md                # Project documentation
├── vite.config.ts           # Vite configuration
├── public/                  # Static assets
│   └── avatars/            # Avatar images
└── src/
    ├── App.tsx             # Main app component
    ├── App.css             # App styles
    ├── index.css           # Global styles
    ├── main.tsx            # Entry point
    ├── components/         # Reusable components
    │   ├── CursorSpotlight.tsx
    │   ├── Navigation.tsx
    │   └── ParticleBackground.tsx
    ├── sections/           # Page sections
    │   ├── LoginSection.tsx
    │   ├── AvatarGallery.tsx
    │   ├── ScriptInput.tsx
    │   ├── HistoryGrid.tsx
    │   └── CreditsSection.tsx
    ├── services/           # API services
    │   └── heygenApi.ts    # Heygen API integration
    ├── store/              # State management
    │   └── appStore.ts     # Zustand store
    └── types/              # TypeScript types
        └── index.ts
```

---

## 🎯 Next Steps

### Features to Add

1. **User Authentication**
   - Add Firebase Auth or Auth0
   - Store user videos per account

2. **Video Storage**
   - Connect AWS S3 or Cloudinary
   - Store generated videos permanently

3. **Payment Integration**
   - Add Stripe for credit purchases
   - Real payment processing

4. **Analytics**
   - Add Google Analytics
   - Track video generations

---

## 📞 Support

If you get stuck:

1. **GitHub Issues**: Check [github.com/vercel/vercel/issues](https://github.com/vercel/vercel/issues)
2. **Vercel Docs**: [vercel.com/docs](https://vercel.com/docs)
3. **Heygen Docs**: [docs.heygen.com](https://docs.heygen.com)

---

## ✅ Checklist

- [ ] GitHub account created
- [ ] Repository created
- [ ] Code pushed to GitHub
- [ ] Vercel account created
- [ ] Project imported to Vercel
- [ ] Environment variables added
- [ ] Site deployed successfully
- [ ] Test video generation works
- [ ] Custom domain added (optional)

---

**You're all set!** 🎉 Your AvatarGen Studio will be live and ready to generate real videos with Heygen API.
