# AvatarGen Studio

An AI-powered avatar video generation platform built with React, TypeScript, and the Heygen API.

![AvatarGen Studio](https://img.shields.io/badge/Built%20with-React%20%2B%20TypeScript-blue)
![Heygen API](https://img.shields.io/badge/Powered%20by-Heygen%20API-purple)

## 🚀 Live Demo

**Current Deployment**: [https://s6cpnoramx4yi.ok.kimi.link](https://s6cpnoramx4yi.ok.kimi.link)

## ✨ Features

- 🎭 **7 AI Avatars** - Choose from diverse presenters
- 📝 **Script Input** - Write or upload your script
- 🎙️ **Real Voices** - 100+ voices from Heygen
- 🎬 **HD Video Generation** - 1280x720 output
- 💳 **Credit System** - Purchase credits for generations
- 📚 **Video History** - Manage all your creations
- 📱 **Responsive Design** - Works on all devices

## 🛠️ Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **State Management**: Zustand
- **API**: Heygen API v2
- **Animations**: Framer Motion
- **Icons**: Lucide React

## 🏁 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn
- Heygen API key ([Get one here](https://app.heygen.com/settings/api))

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/avatargen-studio.git
cd avatargen-studio

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env and add your Heygen API key

# Start development server
npm run dev
```

### Build for Production

```bash
npm run build
```

## 🔐 Environment Variables

Create a `.env` file in the root directory:

```env
VITE_HEYGEN_API_KEY=your_heygen_api_key_here
```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
├── sections/           # Page sections
├── services/           # API services
│   └── heygenApi.ts   # Heygen API integration
├── store/              # State management
├── types/              # TypeScript types
└── hooks/              # Custom React hooks
```

## 🎯 Heygen API Integration

The app integrates with Heygen API for:

- **Avatar Listing** - `GET /v2/avatars`
- **Voice Listing** - `GET /v2/voices`
- **Video Generation** - `POST /v2/video/generate`
- **Status Polling** - `GET /v1/video_status.get`

See [Heygen API Docs](https://docs.heygen.com) for more details.

## 🚀 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project on [Vercel](https://vercel.com)
3. Add environment variables
4. Deploy!

See [GITHUB_VERCEL_SETUP.md](./GITHUB_VERCEL_SETUP.md) for detailed instructions.

## 📝 Usage

1. **Login** - Use any email/password (demo mode)
2. **Select Avatar** - Choose from 7 AI presenters
3. **Write Script** - Enter text or upload a file
4. **Select Voice** - Pick from 100+ Heygen voices
5. **Generate** - Create your video (1 credit)
6. **Download** - Get your HD video when ready

## 💳 Credit System

| Package | Credits | Price |
|---------|---------|-------|
| Starter | 10 | $9.99 |
| Pro | 50 | $39.99 |
| Enterprise | 200 | $129.99 |

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🙏 Acknowledgments

- [Heygen](https://heygen.com) for the amazing API
- [shadcn/ui](https://ui.shadcn.com) for the UI components
- [Vite](https://vitejs.dev) for the build tool

---

Built with ❤️ using React + Heygen API
